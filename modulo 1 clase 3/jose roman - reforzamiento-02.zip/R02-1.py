"""1. El valor de ‘¡HI TuNombre Apellido!’ imprimirlo en consola, el texto
debe ser un string y deberás guardarlo en una variable llamada mi_saludo.
Tu nombre completo debe estar en otra variable."""

mi_saludo = "Hi, amigos"
nombre_completo = "Jose Francisco Roman Ferreyra"
print("{} soy {}".format(mi_saludo, nombre_completo))