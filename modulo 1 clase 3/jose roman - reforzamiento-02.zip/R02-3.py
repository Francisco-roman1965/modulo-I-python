"""3. Crear una variable tipo string, luego súmala con otra variable tipo int,
para esto convertir una de las variables para realizar este procedimiento
sin errores. Mostrar la suma en pantalla."""

variable_string = "25"
variable_int = 10
suma = int(variable_string) + variable_int
print("La suma es:", suma)