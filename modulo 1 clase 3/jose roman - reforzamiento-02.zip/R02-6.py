"""6. Calcular la media de 5 datos (floats), cada dato debe estar en una variable
y la media también. Mostrar el resultado en pantalla y el tipo de dato
también mostrarlo."""

" Definición de las 5 variables con datos float
dato1 = 15.75
dato2 = 23.40
dato3 = 18.25
dato4 = 12.90
dato5 = 20.15

" Cálculo de la media
media = (dato1 + dato2 + dato3 + dato4 + dato5) / 5

" Mostrar el resultado en pantalla
print("=== RESULTADOS ===")
print(f"Dato 1: {dato1} - Tipo: {type(dato1)}")
print(f"Dato 2: {dato2} - Tipo: {type(dato2)}")
print(f"Dato 3: {dato3} - Tipo: {type(dato3)}")
print(f"Dato 4: {dato4} - Tipo: {type(dato4)}")
print(f"Dato 5: {dato5} - Tipo: {type(dato5)}")
print(f"Media: {media} - Tipo: {type(media)}")
