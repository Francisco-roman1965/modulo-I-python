"""2. Crea una variable tipo int. Luego, multiplica por 10 y restar el valor de
10. Debes hacer todo esto en dos pasos. Finalmente convertirlo a float y
mostrar el resultado por pantalla y el tipo de variable también."""

numero_entero = 20.35
operacion = (numero_entero * 10) - 10
resultado_float = float(operacion)

print(f"Resultado: {resultado_float} | Tipo: {type(resultado_float)}")
